import React from 'react';
import { 
  LayoutDashboard, 
  Sun, 
  CheckSquare, 
  Wallet, 
  Sparkles,
  Plus
} from 'lucide-react';
import { ScreenType } from '../types';

interface MobileNavProps {
  currentScreen: ScreenType;
  onSelectScreen: (screen: ScreenType) => void;
  onOpenQuickAdd: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentScreen,
  onSelectScreen,
  onOpenQuickAdd
}) => {
  const items = [
    { id: 'dashboard' as ScreenType, label: 'Inicio', icon: LayoutDashboard },
    { id: 'my-day' as ScreenType, label: 'Mi Día', icon: Sun },
    { id: 'tasks' as ScreenType, label: 'Tareas', icon: CheckSquare },
    { id: 'money' as ScreenType, label: 'Dinero', icon: Wallet },
    { id: 'ai-assistant' as ScreenType, label: 'IA', icon: Sparkles, highlight: true },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-xl border-t border-slate-800/80 px-3 py-2 flex items-center justify-around md:hidden shadow-2xl pb-safe text-slate-400">
      {items.slice(0, 2).map((item) => {
        const Icon = item.icon;
        const active = currentScreen === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onSelectScreen(item.id)}
            className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer ${
              active ? 'text-indigo-400 font-bold' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Icon className={`w-5 h-5 ${active ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
            <span className="text-[10px] mt-0.5">{item.label}</span>
          </button>
        );
      })}

      {/* Floating Center Action Button */}
      <button
        onClick={onOpenQuickAdd}
        className="w-12 h-12 -mt-5 rounded-2xl bg-indigo-500 hover:bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-500/40 active:scale-95 transition-all cursor-pointer ring-4 ring-slate-950"
        aria-label="Agregar nuevo elemento"
      >
        <Plus className="w-6 h-6 stroke-[2.5]" />
      </button>

      {items.slice(2).map((item) => {
        const Icon = item.icon;
        const active = currentScreen === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onSelectScreen(item.id)}
            className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer ${
              active ? 'text-indigo-400 font-bold' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Icon className={`w-5 h-5 ${active ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
            <span className="text-[10px] mt-0.5">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
