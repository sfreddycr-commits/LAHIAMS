import React, { useState } from 'react';
import { 
  Search, 
  Bell, 
  Sparkles, 
  Menu,
  X,
  Compass,
  Calendar as CalendarIcon,
  FolderKanban,
  FileText,
  Inbox,
  Settings,
  Smartphone,
  Monitor
} from 'lucide-react';
import { ScreenType } from '../types';
import { USER_PROFILE } from '../data';

interface HeaderProps {
  currentScreen: ScreenType;
  onSelectScreen: (screen: ScreenType) => void;
  onOpenQuickAdd: () => void;
  isMobileMockup: boolean;
  onToggleMobileMockup: () => void;
  inboxCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentScreen,
  onSelectScreen,
  onOpenQuickAdd,
  isMobileMockup,
  onToggleMobileMockup,
  inboxCount,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const getScreenTitle = () => {
    switch (currentScreen) {
      case 'dashboard': return 'Dashboard';
      case 'my-day': return 'Mi Día';
      case 'tasks': return 'Tareas';
      case 'calendar': return 'Calendario';
      case 'projects': return 'Proyectos';
      case 'money': return 'Dinero & Finanzas';
      case 'notes': return 'Notas';
      case 'inbox': return 'Inbox';
      case 'ai-assistant': return 'Asistente IA';
      case 'settings': return 'Configuración';
      default: return 'LAHIAM’S';
    }
  };

  const navItems: { id: ScreenType; label: string; icon: any }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: Compass },
    { id: 'my-day', label: 'Mi Día', icon: CalendarIcon },
    { id: 'tasks', label: 'Tareas', icon: CalendarIcon },
    { id: 'calendar', label: 'Calendario', icon: CalendarIcon },
    { id: 'projects', label: 'Proyectos', icon: FolderKanban },
    { id: 'money', label: 'Dinero', icon: FolderKanban },
    { id: 'notes', label: 'Notas', icon: FileText },
    { id: 'inbox', label: 'Inbox', icon: Inbox },
    { id: 'ai-assistant', label: 'Asistente IA', icon: Sparkles },
    { id: 'settings', label: 'Configuración', icon: Settings },
  ];

  return (
    <>
      <header className="h-16 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80 px-4 md:px-6 flex items-center justify-between sticky top-0 z-30 text-slate-200">
        {/* Left: Mobile Menu Toggle & Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="p-2 -ml-2 text-slate-400 hover:text-white hover:bg-slate-900 rounded-xl md:hidden cursor-pointer"
            aria-label="Abrir menú"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base md:text-lg font-black text-white tracking-tight">
                {getScreenTitle()}
              </h2>
              <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 hidden sm:block">
              {USER_PROFILE.dateFormatted}
            </p>
          </div>
        </div>

        {/* Center/Right: Global Search & Action Controls */}
        <div className="flex items-center gap-2.5">
          {/* Quick Search */}
          <div className="relative hidden sm:block w-48 lg:w-64">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar (⌘K)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 text-slate-200 placeholder-slate-500 text-xs rounded-2xl pl-9 pr-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium"
            />
          </div>

          {/* Desktop/Mobile Device Frame Toggle */}
          <button
            onClick={onToggleMobileMockup}
            className={`px-3 py-1.5 rounded-2xl text-xs font-bold border flex items-center gap-1.5 transition-colors cursor-pointer ${
              isMobileMockup 
                ? 'bg-indigo-500 border-indigo-400 text-white shadow-md shadow-indigo-500/30' 
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
            }`}
            title="Alternar vista móvil / desktop"
          >
            {isMobileMockup ? (
              <>
                <Smartphone className="w-3.5 h-3.5 text-white" />
                <span className="hidden sm:inline">Vista Móvil</span>
              </>
            ) : (
              <>
                <Monitor className="w-3.5 h-3.5 text-indigo-400" />
                <span className="hidden sm:inline">Desktop</span>
              </>
            )}
          </button>

          {/* AI Quick Sparkle Shortcut */}
          <button
            onClick={() => onSelectScreen('ai-assistant')}
            className="flex items-center gap-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 px-3 py-1.5 rounded-2xl text-xs font-bold transition-all cursor-pointer border border-indigo-500/30"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">AI Copilot</span>
          </button>

          {/* Notification Bell */}
          <div className="relative">
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent hover:border-slate-800 rounded-2xl relative transition-colors cursor-pointer"
              title="Notificaciones"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-slate-950"></span>
            </button>

            {/* Notification Dropdown */}
            {notificationsOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 p-4 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <h4 className="text-xs font-bold text-white">Notificaciones</h4>
                  <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider cursor-pointer">Marcar leídas</span>
                </div>
                <div className="mt-2 space-y-2 max-h-60 overflow-y-auto">
                  <div className="p-2.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/20 text-xs">
                    <p className="font-bold text-white">Reunión de Diseño en 15m</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Google Meet • 09:00 AM</p>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs">
                    <p className="font-bold text-slate-200">Suscripción Netflix vence mañana</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">$15.99 Débito automático</p>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs">
                    <p className="font-bold text-slate-200">1 tarea de alta prioridad pendiente</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Revisar propuesta financiera Q3</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* User Avatar */}
          <button 
            onClick={() => onSelectScreen('settings')}
            className="flex items-center gap-2 cursor-pointer focus:outline-none"
          >
            <img
              src={USER_PROFILE.avatar}
              alt={USER_PROFILE.name}
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-xl object-cover border border-slate-700 shadow-xs hover:border-indigo-500 transition-all"
            />
          </button>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-72 max-w-[80vw] bg-slate-950 border-r border-slate-800 h-full flex flex-col p-5 shadow-2xl z-10 text-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-indigo-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/30">
                  <Compass className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-white">LAHIAM’S</h3>
                  <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Bento Grid</p>
                </div>
              </div>
              <button 
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = currentScreen === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectScreen(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-semibold transition-colors ${
                      active ? 'bg-indigo-500 text-white font-bold shadow-md shadow-indigo-500/20' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="pt-4 border-t border-slate-800">
              <div className="flex items-center gap-3">
                <img
                  src={USER_PROFILE.avatar}
                  alt={USER_PROFILE.name}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                />
                <div>
                  <p className="text-xs font-bold text-white">{USER_PROFILE.fullName}</p>
                  <p className="text-[10px] text-slate-400">{USER_PROFILE.plan}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
