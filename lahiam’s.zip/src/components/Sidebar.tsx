import React from 'react';
import { 
  LayoutDashboard, 
  Sun, 
  CheckSquare, 
  Calendar as CalendarIcon, 
  FolderKanban, 
  Wallet, 
  FileText, 
  Inbox, 
  Sparkles, 
  Settings, 
  Plus,
  Compass
} from 'lucide-react';
import { ScreenType } from '../types';
import { USER_PROFILE } from '../data';

interface SidebarProps {
  currentScreen: ScreenType;
  onSelectScreen: (screen: ScreenType) => void;
  onOpenQuickAdd: () => void;
  inboxCount: number;
  pendingTasksCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentScreen,
  onSelectScreen,
  onOpenQuickAdd,
  inboxCount,
  pendingTasksCount,
}) => {
  const mainNav = [
    { id: 'dashboard' as ScreenType, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'my-day' as ScreenType, label: 'Mi Día', icon: Sun },
    { id: 'tasks' as ScreenType, label: 'Tareas', icon: CheckSquare, badge: pendingTasksCount > 0 ? pendingTasksCount : undefined },
    { id: 'calendar' as ScreenType, label: 'Calendario', icon: CalendarIcon },
  ];

  const orgNav = [
    { id: 'projects' as ScreenType, label: 'Proyectos', icon: FolderKanban },
    { id: 'money' as ScreenType, label: 'Dinero', icon: Wallet },
    { id: 'notes' as ScreenType, label: 'Notas', icon: FileText },
    { id: 'inbox' as ScreenType, label: 'Inbox', icon: Inbox, badge: inboxCount > 0 ? inboxCount : undefined },
  ];

  const aiNav = [
    { id: 'ai-assistant' as ScreenType, label: 'Asistente IA', icon: Sparkles, highlight: true },
  ];

  return (
    <aside className="w-64 bg-slate-950/80 backdrop-blur-xl border-r border-slate-800/80 flex flex-col h-screen shrink-0 sticky top-0 select-none hidden md:flex text-slate-300">
      {/* Brand Header */}
      <div className="p-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30 ring-1 ring-white/20">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-black text-white text-base tracking-tight leading-none flex items-center gap-1.5">
              <span>LAHIAM’S</span>
            </h1>
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-indigo-400">Bento Sanctuary</span>
          </div>
        </div>
      </div>

      {/* Quick Add CTA */}
      <div className="px-4 mb-2">
        <button
          onClick={onOpenQuickAdd}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-indigo-500 hover:bg-indigo-600 text-white rounded-2xl text-xs font-bold shadow-lg shadow-indigo-500/30 transition-all duration-200 cursor-pointer active:scale-[0.98]"
        >
          <Plus className="w-4 h-4" />
          <span>Acción Rápida</span>
        </button>
      </div>

      {/* Navigation Sections */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-6 scrollbar-thin">
        {/* Principal Section */}
        <div>
          <div className="px-3 mb-2 text-[10px] font-black tracking-[0.2em] text-slate-500 uppercase">
            Principal
          </div>
          <nav className="space-y-1">
            {mainNav.map((item) => {
              const Icon = item.icon;
              const active = currentScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectScreen(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                    active
                      ? 'bg-slate-900 border border-slate-800 text-white shadow-md shadow-indigo-500/5 ring-1 ring-slate-700/50'
                      : 'text-slate-400 hover:bg-slate-900/60 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${active ? 'text-indigo-400' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      active ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Organización Section */}
        <div>
          <div className="px-3 mb-2 text-[10px] font-black tracking-[0.2em] text-slate-500 uppercase">
            Organización
          </div>
          <nav className="space-y-1">
            {orgNav.map((item) => {
              const Icon = item.icon;
              const active = currentScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectScreen(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                    active
                      ? 'bg-slate-900 border border-slate-800 text-white shadow-md shadow-indigo-500/5 ring-1 ring-slate-700/50'
                      : 'text-slate-400 hover:bg-slate-900/60 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${active ? 'text-indigo-400' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      active ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Inteligencia AI Section */}
        <div>
          <div className="px-3 mb-2 text-[10px] font-black tracking-[0.2em] text-slate-500 uppercase">
            Inteligencia
          </div>
          <nav className="space-y-1">
            {aiNav.map((item) => {
              const Icon = item.icon;
              const active = currentScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectScreen(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                    active
                      ? 'bg-slate-900 border border-indigo-500/40 text-indigo-300 shadow-md shadow-indigo-500/10'
                      : 'text-slate-400 hover:bg-slate-900/60 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span>{item.label}</span>
                  </div>
                  <span className="text-[9px] font-black tracking-widest bg-indigo-500 text-white px-2 py-0.5 rounded-md uppercase">
                    GENAI
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* User Profile Footer */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/60">
        <div className="flex items-center justify-between p-2 rounded-2xl bg-slate-900/50 border border-slate-800/70 hover:bg-slate-900 transition-colors cursor-pointer group">
          <div 
            onClick={() => onSelectScreen('settings')} 
            className="flex items-center gap-2.5 min-w-0"
          >
            <img
              src={USER_PROFILE.avatar}
              alt={USER_PROFILE.name}
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-xl object-cover border border-slate-700 shadow-xs"
            />
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate leading-tight group-hover:text-indigo-400">
                {USER_PROFILE.name}
              </p>
              <p className="text-[10px] text-slate-400 truncate">
                {USER_PROFILE.plan}
              </p>
            </div>
          </div>
          <button
            onClick={() => onSelectScreen('settings')}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="Configuración"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
