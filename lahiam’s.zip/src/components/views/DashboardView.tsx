import React from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Circle, 
  FolderKanban, 
  Calendar as CalendarIcon, 
  TrendingUp, 
  Clock, 
  Plus,
  AlertCircle
} from 'lucide-react';
import { Task, Project, ScreenType } from '../../types';
import { USER_PROFILE } from '../../data';

interface DashboardViewProps {
  tasks: Task[];
  projects: Project[];
  onToggleTask: (taskId: string) => void;
  onNavigate: (screen: ScreenType) => void;
  onOpenQuickAdd: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  tasks,
  projects,
  onToggleTask,
  onNavigate,
  onOpenQuickAdd
}) => {
  const pendingTasks = tasks.filter(t => !t.completed);
  const completedTasks = tasks.filter(t => t.completed);

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-in fade-in duration-200 pb-12 text-slate-200">
      {/* Top Greeting Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-3 py-1 rounded-full">
              Bento Sanctuary
            </span>
            <span className="text-xs text-slate-500 font-medium">
              {USER_PROFILE.dateFormatted}
            </span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black text-white mt-2 tracking-tight">
            Buenos días, {USER_PROFILE.name}.
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Tienes <span className="font-bold text-white">{pendingTasks.length} tareas pendientes</span> y 3 reuniones sincronizadas para hoy.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => onNavigate('my-day')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-bold text-slate-200 hover:text-white hover:border-slate-700 shadow-md transition-all cursor-pointer"
          >
            <CalendarIcon className="w-4 h-4 text-indigo-400" />
            <span>Ver Mi Día</span>
          </button>
          <button
            onClick={onOpenQuickAdd}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-indigo-500 text-white text-xs font-bold hover:bg-indigo-600 shadow-lg shadow-indigo-500/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Acción Rápida</span>
          </button>
        </div>
      </div>

      {/* AI Intelligence Bento Hero Block */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-[2.5rem] p-6 sm:p-7 relative overflow-hidden shadow-2xl">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-indigo-500/30 ring-1 ring-white/20">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-400">
                Resumen AI • Enfoque Diario
              </span>
              <span className="text-[11px] text-slate-500 font-medium">Actualizado hace 5 min</span>
            </div>
            <p className="text-sm sm:text-base text-slate-200 font-medium mt-1.5 leading-relaxed">
              Tienes 3 reuniones importantes hoy. Sugerencia estratégica: preparar los entregables para la 
              <span className="font-bold text-indigo-400"> presentación de diseño a las 14:00</span> antes del almuerzo para evitar retrasos.
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <button 
                onClick={() => onNavigate('ai-assistant')}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-white bg-indigo-500 hover:bg-indigo-600 px-4 py-2 rounded-xl shadow-lg shadow-indigo-500/20 transition-all cursor-pointer"
              >
                <span>Optimizar mi agenda con IA</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button 
                onClick={() => onNavigate('my-day')}
                className="text-xs font-bold text-slate-400 hover:text-white px-3 py-2 transition-colors cursor-pointer"
              >
                Ver timeline completo
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bento Grid: Active Projects & Quick Financial Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Projects (2 columns on lg) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-[2.5rem] p-6 sm:p-7 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2.5">
                <FolderKanban className="w-5 h-5 text-indigo-400" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">Proyectos Activos</h2>
              </div>
              <button 
                onClick={() => onNavigate('projects')}
                className="text-xs font-bold text-indigo-400 hover:text-indigo-300 cursor-pointer"
              >
                Ver todos ({projects.length})
              </button>
            </div>

            {/* Project Cards Bento Sub-Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {projects.slice(0, 2).map((project) => (
                <div 
                  key={project.id}
                  onClick={() => onNavigate('projects')}
                  className="p-5 rounded-3xl bg-slate-950/60 border border-slate-800/90 hover:border-indigo-500/40 hover:bg-slate-950 transition-all cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                        project.status === 'En Progreso' 
                          ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' 
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {project.status}
                      </span>
                      <span className="text-xs font-black text-indigo-400">{project.progress}%</span>
                    </div>

                    <h3 className="text-xs sm:text-sm font-bold text-white mt-3 group-hover:text-indigo-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                      {project.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800/80">
                    {/* Progress Bar */}
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div 
                        className="bg-indigo-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${project.progress}%` }}
                      />
                    </div>

                    <div className="mt-3 flex items-center justify-between text-[10px] font-medium text-slate-500">
                      <span>{project.tasksCompleted}/{project.tasksTotal} tareas</span>
                      <span>Vence {project.dueDate}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Add project hint */}
          <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>¿Nuevo objetivo en mente?</span>
            <button 
              onClick={onOpenQuickAdd}
              className="text-xs font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Crear proyecto</span>
            </button>
          </div>
        </div>

        {/* Financial Bento Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] p-6 sm:p-7 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2.5">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">Finanzas del Mes</h2>
              </div>
              <button 
                onClick={() => onNavigate('money')}
                className="text-xs font-bold text-indigo-400 hover:text-indigo-300 cursor-pointer"
              >
                Detalle
              </button>
            </div>

            <div className="p-5 rounded-3xl bg-slate-950/80 border border-slate-800/90 relative overflow-hidden">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Saldo Total Disponible</span>
              <div className="text-3xl font-black text-white mt-1 tracking-tight">
                $24,500.00
              </div>
              <div className="mt-2 inline-flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                <span>+5.2% vs mes anterior</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-4">
              <div className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/20">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Ingresos</span>
                <p className="text-sm font-black text-emerald-300 mt-0.5">+$12,000</p>
              </div>
              <div className="p-3.5 rounded-2xl bg-rose-950/20 border border-rose-500/20">
                <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider">Gastos</span>
                <p className="text-sm font-black text-rose-300 mt-0.5">-$8,450</p>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-800/80">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium">Recurrente Próximo</span>
              <span className="font-bold text-white">Netflix • $15.99</span>
            </div>
          </div>
        </div>
      </div>

      {/* Prioridades de Hoy Bento Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] p-6 sm:p-7 shadow-2xl">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            <Clock className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">Prioridades de Hoy</h2>
            <span className="text-[10px] font-black px-2.5 py-0.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-full">
              {pendingTasks.length} restantes
            </span>
          </div>
          <button 
            onClick={() => onNavigate('tasks')}
            className="text-xs font-bold text-indigo-400 hover:text-indigo-300 cursor-pointer"
          >
            Ver lista de tareas
          </button>
        </div>

        <div className="space-y-2.5">
          {tasks.slice(0, 5).map((task) => (
            <div 
              key={task.id}
              onClick={() => onToggleTask(task.id)}
              className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all cursor-pointer ${
                task.completed
                  ? 'bg-slate-950/40 border-slate-800/50 opacity-60'
                  : 'bg-slate-950/80 border-slate-800/90 hover:border-indigo-500/40 hover:bg-slate-950'
              }`}
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleTask(task.id);
                  }}
                  className="text-indigo-400 hover:scale-110 transition-transform cursor-pointer"
                >
                  {task.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-500 hover:text-indigo-400" />
                  )}
                </button>

                <div className="min-w-0">
                  <p className={`text-xs sm:text-sm font-bold truncate ${
                    task.completed ? 'line-through text-slate-500' : 'text-slate-200'
                  }`}>
                    {task.title}
                  </p>
                  <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-500">
                    {task.time && <span className="font-semibold text-slate-400">{task.time}</span>}
                    {task.project && (
                      <>
                        <span>•</span>
                        <span className="font-semibold text-indigo-400">{task.project}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Priority pill */}
              <div className="flex items-center gap-2 shrink-0">
                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                  task.priority === 'Alta'
                    ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    : task.priority === 'Media'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    : 'bg-slate-800 text-slate-400'
                }`}>
                  {task.priority}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
