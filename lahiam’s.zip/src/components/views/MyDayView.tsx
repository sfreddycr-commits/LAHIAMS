import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Video, 
  CheckCircle2, 
  Circle, 
  Plus, 
  AlertCircle, 
  Sparkles,
  ChevronLeft,
  ChevronRight,
  MoreVertical,
  Check
} from 'lucide-react';
import { DayEvent, Task } from '../../types';

interface MyDayViewProps {
  events: DayEvent[];
  tasks: Task[];
  onToggleTask: (taskId: string) => void;
  onOpenQuickAdd: () => void;
}

export const MyDayView: React.FC<MyDayViewProps> = ({
  events,
  tasks,
  onToggleTask,
  onOpenQuickAdd
}) => {
  const [selectedDay, setSelectedDay] = useState(24);

  const daysStrip = [
    { dayNumber: 23, dayName: 'Lun', isToday: false },
    { dayNumber: 24, dayName: 'Mar', isToday: true },
    { dayNumber: 25, dayName: 'Mié', isToday: false },
    { dayNumber: 26, dayName: 'Jue', isToday: false },
    { dayNumber: 27, dayName: 'Vie', isToday: false },
  ];

  const morningEvents = events.filter(e => e.timeSlot === 'morning');
  const afternoonEvents = events.filter(e => e.timeSlot === 'afternoon');
  const eveningEvents = events.filter(e => e.timeSlot === 'evening');

  const unassignedTasks = tasks.filter(t => !t.completed && !t.time);
  const completedToday = tasks.filter(t => t.completed);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200 text-slate-200">
      {/* Top Header & Day Navigation Bento Box */}
      <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 p-6 sm:p-7 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em]">
                Octubre 2023
              </span>
            </div>
            <h1 className="text-xl sm:text-3xl font-black text-white mt-1 tracking-tight">
              Martes, 24 de Octubre
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={onOpenQuickAdd}
              className="flex items-center gap-2 px-5 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded-2xl text-xs font-bold shadow-lg shadow-indigo-500/30 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Agregar a mi día</span>
            </button>
          </div>
        </div>

        {/* Days selector strip */}
        <div className="mt-6 grid grid-cols-5 gap-2 sm:gap-3">
          {daysStrip.map((item) => {
            const selected = selectedDay === item.dayNumber;
            return (
              <button
                key={item.dayNumber}
                onClick={() => setSelectedDay(item.dayNumber)}
                className={`flex flex-col items-center py-3 px-2 rounded-2xl transition-all cursor-pointer ${
                  selected
                    ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/40 font-bold scale-[1.02]'
                    : 'bg-slate-950/60 border border-slate-800 text-slate-400 hover:bg-slate-950 hover:text-slate-200'
                }`}
              >
                <span className="text-[10px] uppercase font-bold tracking-widest opacity-80">{item.dayName}</span>
                <span className="text-base sm:text-xl font-black mt-0.5">{item.dayNumber}</span>
                {item.isToday && !selected && (
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1" />
                )}
                {selected && (
                  <span className="w-1.5 h-1.5 rounded-full bg-white mt-1" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Timeline */}
        <div className="lg:col-span-2 space-y-6">
          {/* Urgent Tasks Banner */}
          <div className="bg-rose-950/30 border border-rose-500/30 rounded-3xl p-4 sm:p-5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-rose-500/30">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-rose-400">Tarea Urgente</h3>
                <p className="text-xs sm:text-sm text-white font-bold mt-0.5">
                  Enviar reporte financiero mensual • <span className="text-rose-400">Vence a las 5 PM</span>
                </p>
              </div>
            </div>
            <button 
              onClick={() => onToggleTask(tasks[0]?.id || '')}
              className="px-4 py-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-bold transition-colors shrink-0 cursor-pointer shadow-md"
            >
              Completar
            </button>
          </div>

          {/* Mañana (Morning) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">
                Mañana (08:00 - 12:00)
              </span>
              <span className="text-[11px] text-slate-500 font-medium">{morningEvents.length} eventos</span>
            </div>

            <div className="space-y-3">
              {morningEvents.map((evt) => (
                <div 
                  key={evt.id}
                  className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex items-center justify-between gap-3 hover:border-indigo-500/40 transition-all"
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-2 h-10 rounded-full bg-indigo-500 shrink-0" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs sm:text-sm font-bold text-white truncate">{evt.title}</span>
                        {evt.priority && (
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${
                            evt.priority === 'High' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                          }`}>
                            {evt.priority}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{evt.subtitle}</p>
                      <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-500" />
                          {evt.time}
                        </span>
                        {evt.meetLink && (
                          <span className="inline-flex items-center gap-1 font-bold text-indigo-400">
                            <Video className="w-3 h-3" />
                            {evt.meetLink}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <button className="p-1.5 text-slate-500 hover:text-slate-200 rounded-lg">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Tarde (Afternoon) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">
                Tarde (12:00 - 18:00)
              </span>
              <span className="text-[11px] text-slate-500 font-medium">{afternoonEvents.length} eventos</span>
            </div>

            <div className="space-y-3">
              {afternoonEvents.map((evt) => (
                <div 
                  key={evt.id}
                  className={`p-5 rounded-3xl border shadow-xl flex items-center justify-between gap-3 transition-all ${
                    evt.isCurrent 
                      ? 'bg-slate-900 border-indigo-500/60 ring-2 ring-indigo-500/20' 
                      : 'bg-slate-900 border-slate-800 hover:border-indigo-500/40'
                  }`}
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className={`w-2 h-10 rounded-full shrink-0 ${
                      evt.isCurrent ? 'bg-indigo-400 animate-pulse' : 'bg-emerald-500'
                    }`} />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs sm:text-sm font-bold text-white truncate">{evt.title}</span>
                        {evt.isCurrent && (
                          <span className="text-[9px] font-black uppercase px-2 py-0.5 bg-indigo-500 text-white rounded-md tracking-wider">
                            En curso
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{evt.subtitle}</p>
                      <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400">
                        <Clock className="w-3 h-3 text-slate-500" />
                        <span>{evt.time}</span>
                      </div>
                    </div>
                  </div>

                  <button className="p-1.5 text-slate-500 hover:text-slate-200 rounded-lg">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Noche (Evening) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">
                Noche (18:00 - 22:00)
              </span>
              <span className="text-[11px] text-slate-500 font-medium">Sin eventos</span>
            </div>

            <div className="p-5 rounded-3xl bg-slate-900/50 border border-dashed border-slate-800 text-center text-xs text-slate-400">
              Espacio libre para descanso, lectura o proyectos personales.
            </div>
          </div>
        </div>

        {/* Right 1 Col: Sin Horario & Completados */}
        <div className="space-y-6">
          {/* Tareas Sin Horario */}
          <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">Sin Horario Fijo</h3>
              <span className="text-[10px] text-slate-500 font-medium">{unassignedTasks.length} pendientes</span>
            </div>

            <div className="space-y-2.5">
              {unassignedTasks.length > 0 ? (
                unassignedTasks.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => onToggleTask(t.id)}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-indigo-500/40 transition-all cursor-pointer"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Circle className="w-4 h-4 text-slate-500 shrink-0" />
                      <span className="text-xs font-semibold text-slate-200 truncate">{t.title}</span>
                    </div>
                    <span className="text-[9px] font-black text-slate-400 px-2 py-0.5 rounded-full bg-slate-800">
                      {t.priority}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500 py-2">Todas las tareas tienen horario asignado.</p>
              )}
            </div>
          </div>

          {/* Completado Hoy */}
          <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">Completado Hoy</h3>
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full">
                {completedToday.length} logradas
              </span>
            </div>

            <div className="space-y-2.5">
              {completedToday.map((t) => (
                <div
                  key={t.id}
                  onClick={() => onToggleTask(t.id)}
                  className="flex items-center gap-3 p-3 rounded-2xl bg-emerald-950/20 border border-emerald-500/20 text-xs text-slate-300 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="line-through truncate text-slate-400">{t.title}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
