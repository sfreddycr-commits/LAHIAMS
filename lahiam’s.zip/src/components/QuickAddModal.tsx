import React, { useState } from 'react';
import { 
  X, 
  CheckSquare, 
  Calendar as CalendarIcon, 
  FolderKanban, 
  FileText, 
  Wallet, 
  Inbox,
  Plus
} from 'lucide-react';
import { Task, Project, Note, Transaction, Priority } from '../types';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTask: (task: Omit<Task, 'id' | 'completed'>) => void;
  onAddProject: (project: Omit<Project, 'id' | 'progress' | 'tasksCompleted'>) => void;
  onAddNote: (note: Omit<Note, 'id' | 'updatedAt'>) => void;
  onAddTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  onAddInbox: (text: string) => void;
}

type AddType = 'task' | 'event' | 'project' | 'note' | 'money' | 'inbox';

export const QuickAddModal: React.FC<QuickAddModalProps> = ({
  isOpen,
  onClose,
  onAddTask,
  onAddProject,
  onAddNote,
  onAddTransaction,
  onAddInbox
}) => {
  const [activeType, setActiveType] = useState<AddType>('task');
  
  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [time, setTime] = useState('14:00');
  const [date, setDate] = useState('2023-10-24');
  const [priority, setPriority] = useState<Priority>('Alta');
  const [project, setProject] = useState('General');
  const [amount, setAmount] = useState('');
  const [transType, setTransType] = useState<'income' | 'expense'>('expense');
  const [category, setCategory] = useState('Alimentación');
  const [noteType, setNoteType] = useState<'Project-related' | 'Idea' | 'Quick note'>('Idea');
  const [noteContent, setNoteContent] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && activeType !== 'inbox' && !noteContent.trim()) return;

    if (activeType === 'task') {
      onAddTask({
        title: title.trim(),
        time,
        date,
        priority,
        project,
        dueDateLabel: `${time} • ${project}`
      });
    } else if (activeType === 'inbox') {
      onAddInbox(title.trim() || 'Nuevo pensamiento');
    } else if (activeType === 'project') {
      onAddProject({
        title: title.trim(),
        description: description.trim() || 'Proyecto organizado con Lumina.',
        status: 'En Progreso',
        tasksTotal: 10,
        dueDate: '30 Nov',
        category: project || 'General'
      });
    } else if (activeType === 'note') {
      onAddNote({
        title: title.trim() || 'Nota sin título',
        content: noteContent.trim() || 'Contenido de nota...',
        type: noteType,
        tags: ['#general'],
        pinned: false,
        favorite: false,
        folder: project || 'Notas'
      });
    } else if (activeType === 'money') {
      onAddTransaction({
        title: title.trim() || (transType === 'income' ? 'Ingreso' : 'Gasto'),
        category,
        amount: parseFloat(amount) || 25.00,
        type: transType,
        paymentMethod: 'Tarjeta',
        date,
        dateGroup: 'Hoy, 15 Mayo',
        icon: transType === 'income' ? 'payments' : 'shopping_cart'
      });
    }

    // Reset & close
    setTitle('');
    setDescription('');
    setNoteContent('');
    setAmount('');
    onClose();
  };

  const types = [
    { id: 'task' as AddType, label: 'Tarea', icon: CheckSquare, color: 'text-indigo-600' },
    { id: 'inbox' as AddType, label: 'Inbox', icon: Inbox, color: 'text-purple-600' },
    { id: 'project' as AddType, label: 'Proyecto', icon: FolderKanban, color: 'text-blue-600' },
    { id: 'note' as AddType, label: 'Nota', icon: FileText, color: 'text-emerald-600' },
    { id: 'money' as AddType, label: 'Dinero', icon: Wallet, color: 'text-amber-600' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity" 
        onClick={onClose}
      />

      {/* Modal Dialog Bento Card */}
      <div className="relative w-full max-w-lg bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-800 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200 text-slate-200">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-indigo-500 text-white flex items-center justify-center shadow-md shadow-indigo-500/30">
              <Plus className="w-4 h-4" />
            </div>
            <h3 className="font-extrabold text-sm text-white">Nuevo Elemento</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Type Selector Pills */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center gap-2 overflow-x-auto scrollbar-none">
          {types.map((t) => {
            const Icon = t.icon;
            const active = activeType === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveType(t.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  active 
                    ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25' 
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white hover:border-slate-700'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${active ? 'text-white' : 'text-indigo-400'}`} />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {activeType === 'task' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5">Título de la Tarea</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Revisar propuesta de arquitectura..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1.5">Hora / Momento</label>
                  <input
                    type="text"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    placeholder="10:00 AM"
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1.5">Prioridad</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as Priority)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white outline-none focus:border-indigo-500 transition-all"
                  >
                    <option value="Alta" className="bg-slate-900 text-white">Alta</option>
                    <option value="Media" className="bg-slate-900 text-white">Media</option>
                    <option value="Baja" className="bg-slate-900 text-white">Baja</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5">Proyecto asignado</label>
                <input
                  type="text"
                  value={project}
                  onChange={(e) => setProject(e.target.value)}
                  placeholder="Proyecto Alpha / Finanzas / Personal"
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all"
                />
              </div>
            </>
          )}

          {activeType === 'inbox' && (
            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1.5">¿Qué tienes en mente?</label>
              <textarea
                rows={4}
                required
                placeholder="Escribe libremente cualquier idea, pensamiento rápido, recordatorio sin procesar..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all resize-none"
              />
            </div>
          )}

          {activeType === 'project' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5">Nombre del Proyecto</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Rediseño Portal Web V3"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5">Descripción del Objetivo</label>
                <textarea
                  rows={2}
                  placeholder="Resumen del entregable y metas clave..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all resize-none"
                />
              </div>
            </>
          )}

          {activeType === 'note' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5">Título de la Nota</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Concepto Arquitectura Frontend"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5">Contenido / Markdown</label>
                <textarea
                  rows={4}
                  placeholder="Escribe tus notas, bullets o reflexiones..."
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all resize-none font-mono text-[11px]"
                />
              </div>
            </>
          )}

          {activeType === 'money' && (
            <>
              <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setTransType('expense')}
                  className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                    transType === 'expense' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Gasto
                </button>
                <button
                  type="button"
                  onClick={() => setTransType('income')}
                  className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                    transType === 'income' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Ingreso
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5">Concepto / Nombre</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Supermercado / Pago Consultoría"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1.5">Monto ($ USD)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 font-bold transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1.5">Categoría</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-2.5 text-xs text-white outline-none focus:border-indigo-500 transition-all"
                  >
                    <option value="Alimentación" className="bg-slate-900 text-white">Alimentación</option>
                    <option value="Servicios" className="bg-slate-900 text-white">Servicios</option>
                    <option value="Ocio" className="bg-slate-900 text-white">Ocio</option>
                    <option value="Transporte" className="bg-slate-900 text-white">Transporte</option>
                    <option value="Ingresos extra" className="bg-slate-900 text-white">Ingresos extra</option>
                    <option value="Salario" className="bg-slate-900 text-white">Salario</option>
                  </select>
                </div>
              </div>
            </>
          )}

          {/* Modal Actions */}
          <div className="pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-2xl text-xs font-bold bg-indigo-500 hover:bg-indigo-600 text-white shadow-lg shadow-indigo-500/30 transition-all cursor-pointer"
            >
              Guardar Elemento
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
