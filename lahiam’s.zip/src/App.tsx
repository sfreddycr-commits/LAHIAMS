/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ScreenType, Task, DayEvent, Project, Transaction, Note, InboxItem, Priority } from './types';
import { 
  INITIAL_TASKS, 
  INITIAL_DAY_EVENTS, 
  INITIAL_PROJECTS, 
  INITIAL_TRANSACTIONS, 
  INITIAL_NOTES, 
  INITIAL_INBOX, 
  USER_PROFILE 
} from './data';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { Header } from './components/Header';
import { QuickAddModal } from './components/QuickAddModal';
import { DashboardView } from './components/views/DashboardView';
import { MyDayView } from './components/views/MyDayView';
import { TasksView } from './components/views/TasksView';
import { CalendarView } from './components/views/CalendarView';
import { ProjectsView } from './components/views/ProjectsView';
import { MoneyView } from './components/views/MoneyView';
import { NotesView } from './components/views/NotesView';
import { InboxView } from './components/views/InboxView';
import { AiAssistantView } from './components/views/AiAssistantView';
import { SettingsView } from './components/views/SettingsView';

export default function App() {
  // Navigation & View Modes
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('dashboard');
  const [isMobileMockup, setIsMobileMockup] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);

  // Core Data States
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [dayEvents, setDayEvents] = useState<DayEvent[]>(INITIAL_DAY_EVENTS);
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [notes, setNotes] = useState<Note[]>(INITIAL_NOTES);
  const [inboxItems, setInboxItems] = useState<InboxItem[]>(INITIAL_INBOX);

  // Handlers for Tasks
  const handleToggleTask = (taskId: string) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t));
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  const handleAddTask = (taskData: Omit<Task, 'id' | 'completed'>) => {
    const newTask: Task = {
      ...taskData,
      id: `task-${Date.now()}`,
      completed: false
    };
    setTasks(prev => [newTask, ...prev]);
  };

  // Handlers for Projects
  const handleAddProject = (projectData: Omit<Project, 'id' | 'progress' | 'tasksCompleted'>) => {
    const newProj: Project = {
      ...projectData,
      id: `proj-${Date.now()}`,
      progress: 0,
      tasksCompleted: 0
    };
    setProjects(prev => [newProj, ...prev]);
  };

  // Handlers for Notes
  const handleAddNote = (noteData: Omit<Note, 'id' | 'updatedAt'>) => {
    const newNote: Note = {
      ...noteData,
      id: `note-${Date.now()}`,
      updatedAt: 'Just now'
    };
    setNotes(prev => [newNote, ...prev]);
  };

  const handleUpdateNote = (updated: Note) => {
    setNotes(prev => prev.map(n => n.id === updated.id ? updated : n));
  };

  const handleDeleteNote = (noteId: string) => {
    setNotes(prev => prev.filter(n => n.id !== noteId));
  };

  // Handlers for Transactions
  const handleAddTransaction = (transData: Omit<Transaction, 'id'>) => {
    const newTrans: Transaction = {
      ...transData,
      id: `tr-${Date.now()}`
    };
    setTransactions(prev => [newTrans, ...prev]);
  };

  // Handlers for Inbox
  const handleAddInbox = (text: string) => {
    const newItem: InboxItem = {
      id: `in-${Date.now()}`,
      text,
      createdAt: 'Just now'
    };
    setInboxItems(prev => [newItem, ...prev]);
  };

  const handleConvertInbox = (id: string, type: 'Task' | 'Event' | 'Reminder' | 'Note' | 'Project') => {
    const item = inboxItems.find(i => i.id === id);
    if (!item) return;

    if (type === 'Task') {
      handleAddTask({
        title: item.text,
        priority: 'Media',
        dueDateLabel: 'Hoy'
      });
    } else if (type === 'Note') {
      handleAddNote({
        title: item.text,
        content: `Nota creada desde Inbox: ${item.text}`,
        type: 'Quick note',
        tags: ['#inbox'],
        pinned: false,
        favorite: false
      });
    } else if (type === 'Project') {
      handleAddProject({
        title: item.text,
        description: 'Proyecto derivado de idea en Inbox.',
        status: 'Idea',
        tasksTotal: 3,
        dueDate: 'Sin fecha'
      });
    }

    setInboxItems(prev => prev.map(i => i.id === id ? { ...i, convertedTo: type } : i));
  };

  const handleDeleteInbox = (id: string) => {
    setInboxItems(prev => prev.filter(i => i.id !== id));
  };

  // AI Sync Plan
  const handleApplyPlanToMyDay = () => {
    // Adds suggested structured events to DayEvents
    const aiEvents: DayEvent[] = [
      {
        id: `ai-e1-${Date.now()}`,
        title: 'Bloque Deep Work: Wireframes',
        subtitle: 'Enfoque sugerido por Asistente IA',
        time: '11:00 AM',
        timeSlot: 'morning',
        priority: 'High',
        type: 'work'
      }
    ];
    setDayEvents(prev => [...prev, ...aiEvents]);
  };

  // Reset demo data
  const handleResetData = () => {
    setTasks(INITIAL_TASKS);
    setDayEvents(INITIAL_DAY_EVENTS);
    setProjects(INITIAL_PROJECTS);
    setTransactions(INITIAL_TRANSACTIONS);
    setNotes(INITIAL_NOTES);
    setInboxItems(INITIAL_INBOX);
  };

  const pendingTasksCount = tasks.filter(t => !t.completed).length;
  const inboxCount = inboxItems.filter(i => !i.convertedTo).length;

  const renderActiveScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return (
          <DashboardView
            tasks={tasks}
            projects={projects}
            onToggleTask={handleToggleTask}
            onNavigate={(screen) => setCurrentScreen(screen)}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          />
        );
      case 'my-day':
        return (
          <MyDayView
            events={dayEvents}
            tasks={tasks}
            onToggleTask={handleToggleTask}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          />
        );
      case 'tasks':
        return (
          <TasksView
            tasks={tasks}
            onToggleTask={handleToggleTask}
            onDeleteTask={handleDeleteTask}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          />
        );
      case 'calendar':
        return (
          <CalendarView
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          />
        );
      case 'projects':
        return (
          <ProjectsView
            projects={projects}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          />
        );
      case 'money':
        return (
          <MoneyView
            transactions={transactions}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          />
        );
      case 'notes':
        return (
          <NotesView
            notes={notes}
            onAddNote={handleAddNote}
            onUpdateNote={handleUpdateNote}
            onDeleteNote={handleDeleteNote}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          />
        );
      case 'inbox':
        return (
          <InboxView
            inboxItems={inboxItems}
            onAddInbox={handleAddInbox}
            onConvertInbox={handleConvertInbox}
            onDeleteInbox={handleDeleteInbox}
          />
        );
      case 'ai-assistant':
        return (
          <AiAssistantView
            onApplyPlanToMyDay={handleApplyPlanToMyDay}
          />
        );
      case 'settings':
        return (
          <SettingsView
            onResetData={handleResetData}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-200 font-sans antialiased flex flex-col selection:bg-indigo-500/30 selection:text-indigo-300">
      {isMobileMockup ? (
        /* Mobile Device Frame Container Preview */
        <div className="min-h-screen bg-slate-950 py-6 px-4 flex flex-col items-center justify-center">
          <div className="mb-4 flex items-center justify-between w-full max-w-sm text-slate-400 text-xs">
            <span className="font-bold tracking-wider uppercase text-[10px] text-indigo-400">Vista Móvil Simulada</span>
            <button
              onClick={() => setIsMobileMockup(false)}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold underline cursor-pointer"
            >
              Volver a vista completa
            </button>
          </div>

          {/* Phone Shell */}
          <div className="w-full max-w-[390px] h-[840px] bg-[#020617] rounded-[48px] shadow-2xl border-[10px] border-slate-800/90 flex flex-col overflow-hidden relative ring-1 ring-slate-700/50">
            {/* Phone Notch/Island */}
            <div className="h-7 bg-[#020617] w-full flex items-center justify-center relative shrink-0 pt-2">
              <div className="w-24 h-4 bg-slate-900 rounded-full border border-slate-800" />
            </div>

            {/* Mobile Header */}
            <Header
              currentScreen={currentScreen}
              onSelectScreen={(screen) => setCurrentScreen(screen)}
              onOpenQuickAdd={() => setIsQuickAddOpen(true)}
              isMobileMockup={isMobileMockup}
              onToggleMobileMockup={() => setIsMobileMockup(!isMobileMockup)}
              inboxCount={inboxCount}
            />

            {/* Mobile Screen Body */}
            <main className="flex-1 overflow-y-auto p-4 pb-24 bg-[#020617]">
              {renderActiveScreen()}
            </main>

            {/* Mobile Bottom Nav */}
            <MobileNav
              currentScreen={currentScreen}
              onSelectScreen={(screen) => setCurrentScreen(screen)}
              onOpenQuickAdd={() => setIsQuickAddOpen(true)}
            />
          </div>
        </div>
      ) : (
        /* Standard Responsive Desktop & Tablet Layout */
        <div className="flex h-screen overflow-hidden bg-[#020617]">
          {/* Desktop Left Sidebar */}
          <Sidebar
            currentScreen={currentScreen}
            onSelectScreen={(screen) => setCurrentScreen(screen)}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
            inboxCount={inboxCount}
            pendingTasksCount={pendingTasksCount}
          />

          {/* Main Content Area */}
          <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden bg-[#020617]">
            <Header
              currentScreen={currentScreen}
              onSelectScreen={(screen) => setCurrentScreen(screen)}
              onOpenQuickAdd={() => setIsQuickAddOpen(true)}
              isMobileMockup={isMobileMockup}
              onToggleMobileMockup={() => setIsMobileMockup(!isMobileMockup)}
              inboxCount={inboxCount}
            />

            <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#020617] scrollbar-thin">
              {renderActiveScreen()}
            </main>

            {/* Mobile Bottom Navigation for Small Screen width */}
            <MobileNav
              currentScreen={currentScreen}
              onSelectScreen={(screen) => setCurrentScreen(screen)}
              onOpenQuickAdd={() => setIsQuickAddOpen(true)}
            />
          </div>
        </div>
      )}

      {/* Quick Add Universal Modal */}
      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        onAddTask={handleAddTask}
        onAddProject={handleAddProject}
        onAddNote={handleAddNote}
        onAddTransaction={handleAddTransaction}
        onAddInbox={handleAddInbox}
      />
    </div>
  );
}
